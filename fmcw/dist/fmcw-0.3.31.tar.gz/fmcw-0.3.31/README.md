# FMCW
Based on initial work by Henrik Forsten

Python 3.X implementation of the software layer handling the fmcw3 radar.
Includes acquisition and post-processing scripts.
